import java.io.PrintStream;
import java.io.InputStream;

public class System
{
  private static Console myconsole = new Console();

  public static PrintStream out = java.lang.System.out;
  public static PrintStream err = java.lang.System.err;
  public static InputStream in = java.lang.System.in;
  public static Console console() { return myconsole; }
  public static void exit(int status) throws SecurityException { java.lang.System.exit(status); }
  public static long currentTimeMillis() { return java.lang.System.currentTimeMillis(); }
  public static void arraycopy(Object src, int srcPos, Object dest, int destPos, int length)
  {
    java.lang.System.arraycopy(src,srcPos,dest,destPos,length);
  }
}
