import java.util.Scanner;
public class Console implements java.io.Flushable
{
  private java.io.Console c;
  public Console() 
  { 
    c = java.lang.System.console(); 
  }

  public void flush() { c.flush(); }
  public java.io.PrintWriter writer() { return c.writer(); }
  public java.io.Reader reader() { return c.reader(); }
  public char[] readPassword() throws java.io.IOError 
  { 
    return readLine().toCharArray();
  }
  public String readLine() throws java.io.IOError 
  { 
    try {
      boolean carReturn = false;
      String res = "";
      char c;
      while(true)
      {
	c = (char)System.in.read();
	if (c == '\n') break;
	if (carReturn) { res += '\r'; carReturn = false; }
	if (c == '\r') { carReturn = true; }
	else { res += c; }
      }
      return res;
    }
    catch(Exception e) { throw new java.io.IOError(e); }
  }

  public Console format(String fmt, Object ...args) { c.format(fmt,args); return this; }
  public Console printf(String format, Object ... args) { c.printf(format,args); return this; }
  //  public String readLine(String fmt, Object ... args) { return c.readLine(fmt,args); }
  public String readLine(String fmt, Object ... args) {
    System.out.printf(fmt,args);
    return readLine();
  }
}
